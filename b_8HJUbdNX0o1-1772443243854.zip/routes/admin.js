const express = require('express');
const router = express.Router();
const { isAdmin } = require('../middleware/auth');
const upload = require('../middleware/upload');
const Product = require('../models/Product');
const Category = require('../models/Category');
const Order = require('../models/Order');

// Dashboard admin
router.get('/', isAdmin, async (req, res) => {
  try {
    const totalProducts = await Product.countDocuments();
    const totalOrders = await Order.countDocuments();
    const totalCategories = await Category.countDocuments();
    const totalRevenue = await Order.aggregate([
      {
        $group: {
          _id: null,
          total: { $sum: '$totalPrice' }
        }
      }
    ]);
    
    res.render('admin/dashboard', {
      title: 'Admin Dashboard',
      stats: {
        totalProducts,
        totalOrders,
        totalCategories,
        totalRevenue: totalRevenue[0]?.total || 0
      }
    });
  } catch (error) {
    res.status(500).render('error', { message: error.message });
  }
});

// ========== QUẢN LÝ SẢN PHẨM ==========

// Danh sách sản phẩm
router.get('/products', isAdmin, async (req, res) => {
  try {
    const { search } = req.query;
    let filter = {};
    
    if (search) {
      filter.name = { $regex: search, $options: 'i' };
    }
    
    const products = await Product.find(filter).populate('category').sort({ createdAt: -1 });
    const categories = await Category.find();
    
    res.render('admin/products/list', {
      title: 'Quản lý sản phẩm',
      products,
      categories,
      search: search || ''
    });
  } catch (error) {
    res.status(500).render('error', { message: error.message });
  }
});

// Trang thêm sản phẩm
router.get('/products/add', isAdmin, async (req, res) => {
  try {
    const categories = await Category.find();
    res.render('admin/products/add', {
      title: 'Thêm sản phẩm',
      categories
    });
  } catch (error) {
    res.status(500).render('error', { message: error.message });
  }
});

// Xử lý thêm sản phẩm
router.post('/products/add', isAdmin, upload.single('image'), async (req, res) => {
  try {
    const { name, description, price, category, stock } = req.body;
    
    if (!name || !description || !price || !category || !stock) {
      return res.status(400).json({ error: 'Thông tin không đầy đủ' });
    }
    
    const product = new Product({
      name,
      description,
      price: parseFloat(price),
      category,
      stock: parseInt(stock),
      image: req.file ? `/uploads/${req.file.filename}` : null
    });
    
    await product.save();
    res.json({ success: true, productId: product._id });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Trang sửa sản phẩm
router.get('/products/:id/edit', isAdmin, async (req, res) => {
  try {
    const product = await Product.findById(req.params.id).populate('category');
    const categories = await Category.find();
    
    if (!product) {
      return res.status(404).render('error', { message: 'Không tìm thấy sản phẩm' });
    }
    
    res.render('admin/products/edit', {
      title: 'Chỉnh sửa sản phẩm',
      product,
      categories
    });
  } catch (error) {
    res.status(500).render('error', { message: error.message });
  }
});

// Xử lý sửa sản phẩm
router.post('/products/:id/edit', isAdmin, upload.single('image'), async (req, res) => {
  try {
    const { name, description, price, category, stock } = req.body;
    
    if (!name || !description || !price || !category || !stock) {
      return res.status(400).json({ error: 'Thông tin không đầy đủ' });
    }
    
    const updateData = {
      name,
      description,
      price: parseFloat(price),
      category,
      stock: parseInt(stock)
    };
    
    if (req.file) {
      updateData.image = `/uploads/${req.file.filename}`;
    }
    
    const product = await Product.findByIdAndUpdate(req.params.id, updateData, { new: true });
    res.json({ success: true, product });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Xóa sản phẩm
router.post('/products/:id/delete', isAdmin, async (req, res) => {
  try {
    await Product.findByIdAndDelete(req.params.id);
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ========== QUẢN LÝ DANH MỤC ==========

// Danh sách danh mục
router.get('/categories', isAdmin, async (req, res) => {
  try {
    const { search } = req.query;
    let filter = {};
    
    if (search) {
      filter.name = { $regex: search, $options: 'i' };
    }
    
    const categories = await Category.find(filter).sort({ createdAt: -1 });
    
    res.render('admin/categories/list', {
      title: 'Quản lý danh mục',
      categories,
      search: search || ''
    });
  } catch (error) {
    res.status(500).render('error', { message: error.message });
  }
});

// Thêm danh mục
router.post('/categories/add', isAdmin, async (req, res) => {
  try {
    const { name, description } = req.body;
    
    if (!name) {
      return res.status(400).json({ error: 'Tên danh mục không được để trống' });
    }
    
    const category = new Category({ name, description });
    await category.save();
    
    res.json({ success: true, category });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Sửa danh mục
router.post('/categories/:id/edit', isAdmin, async (req, res) => {
  try {
    const { name, description } = req.body;
    
    if (!name) {
      return res.status(400).json({ error: 'Tên danh mục không được để trống' });
    }
    
    const category = await Category.findByIdAndUpdate(
      req.params.id,
      { name, description },
      { new: true }
    );
    
    res.json({ success: true, category });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Xóa danh mục
router.post('/categories/:id/delete', isAdmin, async (req, res) => {
  try {
    await Category.findByIdAndDelete(req.params.id);
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// ========== QUẢN LÝ ĐƠN HÀNG ==========

// Danh sách đơn hàng
router.get('/orders', isAdmin, async (req, res) => {
  try {
    const { search, status } = req.query;
    let filter = {};
    
    if (search) {
      filter.$or = [
        { customerName: { $regex: search, $options: 'i' } },
        { customerPhone: { $regex: search, $options: 'i' } }
      ];
    }
    
    if (status && status !== 'all') {
      filter.status = status;
    }
    
    const orders = await Order.find(filter)
      .populate('user', 'fullName email')
      .populate('items.product', 'name price')
      .sort({ createdAt: -1 });
    
    res.render('admin/orders/list', {
      title: 'Quản lý đơn hàng',
      orders,
      search: search || '',
      selectedStatus: status || 'all'
    });
  } catch (error) {
    res.status(500).render('error', { message: error.message });
  }
});

// Chi tiết đơn hàng
router.get('/orders/:id', isAdmin, async (req, res) => {
  try {
    const order = await Order.findById(req.params.id)
      .populate('user')
      .populate('items.product');
    
    if (!order) {
      return res.status(404).render('error', { message: 'Không tìm thấy đơn hàng' });
    }
    
    res.render('admin/orders/detail', {
      title: 'Chi tiết đơn hàng',
      order
    });
  } catch (error) {
    res.status(500).render('error', { message: error.message });
  }
});

// Cập nhật trạng thái đơn hàng
router.post('/orders/:id/status', isAdmin, async (req, res) => {
  try {
    const { status } = req.body;
    
    const validStatuses = ['Pending', 'Processing', 'Shipped', 'Delivered', 'Cancelled'];
    if (!validStatuses.includes(status)) {
      return res.status(400).json({ error: 'Trạng thái không hợp lệ' });
    }
    
    const order = await Order.findByIdAndUpdate(
      req.params.id,
      { status, updatedAt: new Date() },
      { new: true }
    );
    
    res.json({ success: true, order });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
