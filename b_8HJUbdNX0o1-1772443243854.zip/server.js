const express = require('express');
const mongoose = require('mongoose');
const session = require('express-session');
const path = require('path');
require('dotenv').config();

const app = express();

// Kết nối MongoDB
mongoose.connect(process.env.MONGODB_URI)
  .then(() => console.log('MongoDB kết nối thành công'))
  .catch(err => console.log('MongoDB kết nối thất bại:', err));

// Cấu hình EJS
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Middleware
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

app.use(session({
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: true,
  cookie: { maxAge: 1000 * 60 * 60 * 24 * 7 } // 7 ngày
}));

// Middleware để pass user vào tất cả views
app.use((req, res, next) => {
  res.locals.user = req.session.user || null;
  res.locals.cart = req.session.cart || [];
  
  // Wrap render để thêm layout
  const originalRender = res.render;
  res.render = function(view, options, callback) {
    // Nếu là file lỗi (error, 404), không dùng layout
    if (view === 'error' || view === '404') {
      return originalRender.call(this, view, options, callback);
    }
    
    // Nếu là file auth, không dùng layout vì chúng tự chứa layout
    if (view.startsWith('auth/')) {
      return originalRender.call(this, view, options, callback);
    }
    
    // Render view content và wrap trong layout
    originalRender.call(this, view, options || {}, (err, html) => {
      if (err) return callback ? callback(err) : res.send(err.message);
      
      // Render layout với body là content
      originalRender.call(this, 'layout', {
        ...options,
        body: html
      }, callback);
    });
  };
  
  next();
});

// Routes
const homeRoutes = require('./routes/home');
const authRoutes = require('./routes/auth');
const userRoutes = require('./routes/user');
const adminRoutes = require('./routes/admin');
const cartRoutes = require('./routes/cart');
const orderRoutes = require('./routes/order');

app.use('/', homeRoutes);
app.use('/auth', authRoutes);
app.use('/user', userRoutes);
app.use('/admin', adminRoutes);
app.use('/cart', cartRoutes);
app.use('/order', orderRoutes);

// 404 handler
app.use((req, res) => {
  res.status(404).render('404');
});

// Error handler
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).render('error', { message: 'Có lỗi xảy ra' });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server chạy trên port ${PORT}`);
  console.log(`Truy cập: http://localhost:${PORT}`);
});
