const express = require('express');
const router = express.Router();
const User = require('../models/User');

// Trang đăng nhập
router.get('/login', (req, res) => {
  res.render('auth/login', { title: 'Đăng nhập' });
});

// Xử lý đăng nhập
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    
    if (!email || !password) {
      return res.render('auth/login', {
        title: 'Đăng nhập',
        error: 'Email và mật khẩu không được để trống'
      });
    }
    
    const user = await User.findOne({ email });
    if (!user) {
      return res.render('auth/login', {
        title: 'Đăng nhập',
        error: 'Email hoặc mật khẩu không đúng'
      });
    }
    
    const isPasswordMatch = await user.comparePassword(password);
    if (!isPasswordMatch) {
      return res.render('auth/login', {
        title: 'Đăng nhập',
        error: 'Email hoặc mật khẩu không đúng'
      });
    }
    
    req.session.user = {
      id: user._id,
      fullName: user.fullName,
      email: user.email,
      phone: user.phone,
      address: user.address,
      role: user.role
    };
    
    if (user.role === 'admin') {
      res.redirect('/admin');
    } else {
      res.redirect('/');
    }
  } catch (error) {
    res.status(500).render('error', { message: error.message });
  }
});

// Trang đăng ký
router.get('/register', (req, res) => {
  res.render('auth/register', { title: 'Đăng ký' });
});

// Xử lý đăng ký
router.post('/register', async (req, res) => {
  try {
    const { fullName, email, phone, address, password, confirmPassword } = req.body;
    
    // Validate
    if (!fullName || !email || !phone || !address || !password || !confirmPassword) {
      return res.render('auth/register', {
        title: 'Đăng ký',
        error: 'Tất cả các trường không được để trống'
      });
    }
    
    if (password !== confirmPassword) {
      return res.render('auth/register', {
        title: 'Đăng ký',
        error: 'Mật khẩu không trùng khớp'
      });
    }
    
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.render('auth/register', {
        title: 'Đăng ký',
        error: 'Email này đã được sử dụng'
      });
    }
    
    const newUser = new User({
      fullName,
      email,
      phone,
      address,
      password
    });
    
    await newUser.save();
    
    req.session.user = {
      id: newUser._id,
      fullName: newUser.fullName,
      email: newUser.email,
      phone: newUser.phone,
      address: newUser.address,
      role: newUser.role
    };
    
    res.redirect('/');
  } catch (error) {
    res.status(500).render('error', { message: error.message });
  }
});

// Đăng xuất
router.get('/logout', (req, res) => {
  req.session.destroy((err) => {
    if (err) {
      return res.status(500).render('error', { message: 'Lỗi đăng xuất' });
    }
    res.redirect('/');
  });
});

module.exports = router;
