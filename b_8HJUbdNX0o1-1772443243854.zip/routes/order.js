const express = require('express');
const router = express.Router();
const { isAuthenticated } = require('../middleware/auth');
const Order = require('../models/Order');
const Product = require('../models/Product');
const Comment = require('../models/Comment');

// Checkout
router.get('/checkout', isAuthenticated, async (req, res) => {
  try {
    const cart = req.session.cart || [];
    
    if (cart.length === 0) {
      return res.redirect('/cart');
    }
    
    let total = 0;
    cart.forEach(item => {
      total += item.price * item.quantity;
    });
    
    res.render('order/checkout', {
      title: 'Thanh toán',
      cart,
      total,
      user: req.session.user
    });
  } catch (error) {
    res.status(500).render('error', { message: error.message });
  }
});

// Xử lý đơn hàng
router.post('/create', isAuthenticated, async (req, res) => {
  try {
    const cart = req.session.cart || [];
    
    if (cart.length === 0) {
      return res.status(400).json({ error: 'Giỏ hàng trống' });
    }
    
    const { customerName, customerPhone, customerAddress } = req.body;
    
    if (!customerName || !customerPhone || !customerAddress) {
      return res.status(400).json({ error: 'Thông tin không đầy đủ' });
    }
    
    let totalPrice = 0;
    const items = [];
    
    for (const item of cart) {
      const product = await Product.findById(item.productId);
      if (product) {
        items.push({
          product: item.productId,
          quantity: item.quantity,
          price: item.price
        });
        totalPrice += item.price * item.quantity;
      }
    }
    
    const order = new Order({
      user: req.session.user.id,
      items,
      totalPrice,
      customerName,
      customerPhone,
      customerAddress
    });
    
    await order.save();
    
    req.session.cart = [];
    
    res.json({ success: true, orderId: order._id });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Xem đơn hàng của user
router.get('/my-orders', isAuthenticated, async (req, res) => {
  try {
    const orders = await Order.find({ user: req.session.user.id })
      .populate('items.product')
      .sort({ createdAt: -1 });
    
    res.render('order/my-orders', {
      title: 'Đơn hàng của tôi',
      orders
    });
  } catch (error) {
    res.status(500).render('error', { message: error.message });
  }
});

// Chi tiết đơn hàng
router.get('/:id', isAuthenticated, async (req, res) => {
  try {
    const order = await Order.findById(req.params.id)
      .populate('items.product')
      .populate('user');
    
    if (!order) {
      return res.status(404).render('error', { message: 'Không tìm thấy đơn hàng' });
    }
    
    // Kiểm tra quyền
    if (order.user._id.toString() !== req.session.user.id) {
      return res.status(403).render('error', { message: 'Bạn không có quyền xem đơn hàng này' });
    }
    
    res.render('order/order-detail', {
      title: 'Chi tiết đơn hàng',
      order
    });
  } catch (error) {
    res.status(500).render('error', { message: error.message });
  }
});

// Hủy đơn hàng
router.post('/:id/cancel', isAuthenticated, async (req, res) => {
  try {
    const order = await Order.findById(req.params.id);
    
    if (!order) {
      return res.status(404).json({ error: 'Không tìm thấy đơn hàng' });
    }
    
    if (order.user.toString() !== req.session.user.id) {
      return res.status(403).json({ error: 'Bạn không có quyền' });
    }
    
    if (order.status !== 'Pending') {
      return res.status(400).json({ error: 'Chỉ có thể hủy đơn hàng đang chờ xử lý' });
    }
    
    order.status = 'Cancelled';
    await order.save();
    
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Thêm bình luận (chỉ user đã mua mới có thể)
router.post('/:productId/comment', isAuthenticated, async (req, res) => {
  try {
    const { rating, text } = req.body;
    const productId = req.params.productId;
    
    if (!rating || !text) {
      return res.status(400).json({ error: 'Vui lòng nhập đầy đủ thông tin' });
    }
    
    // Kiểm tra user đã mua sản phẩm này chưa
    const order = await Order.findOne({
      user: req.session.user.id,
      'items.product': productId,
      status: { $ne: 'Cancelled' }
    });
    
    if (!order) {
      return res.status(403).json({ error: 'Bạn chỉ có thể bình luận khi đã mua sản phẩm' });
    }
    
    const comment = new Comment({
      product: productId,
      user: req.session.user.id,
      order: order._id,
      rating: parseInt(rating),
      text
    });
    
    await comment.save();
    
    // Cập nhật rating sản phẩm
    const comments = await Comment.find({ product: productId });
    const avgRating = comments.reduce((sum, c) => sum + c.rating, 0) / comments.length;
    
    await Product.findByIdAndUpdate(productId, {
      rating: avgRating,
      reviews: comments.length
    });
    
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
